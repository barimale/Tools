using System;
using System.Threading.Tasks;
using SoundManager.WPF.ViewModels.Base;

namespace SoundManager.WPF.ViewModels.Map
{
    public interface ITemplateStateMachine : IStateMachineBase<Triggers, States>
    {
        string ToGraph();
        States MachineState { get; }
        Func<Task> LoadAction { get; set; }
    }
}