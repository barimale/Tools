using SoundManager.WPF.ViewModels.Base;
using Stateless.Graph;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace SoundManager.WPF.ViewModels.Map
{
    public enum States
    {
        Start,
        Loading,
        LoadingComplete,
        LoadingFailed
    }
    public enum Triggers
    {
        Loading,
        LoadingSucceeded,
        LoadingFailed,
        ShowInstance
    }

    public class TemplateStateMachine : StateMachineBase<States, Triggers>, ITemplateStateMachine
    {
        public TemplateStateMachine()
            : base(States.Start)
        {
            //intentionally left blank
        }

        public States MachineState => this.State;
        public Func<Task> LoadAction { get; set; } = async () => { };

        public void Initialize()
        {
            Configure(States.Start)
                .Permit(Triggers.Loading, States.Loading);

            Configure(States.Loading)
                .OnEntryAsync(LoadAction)
                .Permit(Triggers.LoadingSucceeded, States.LoadingComplete)
                .Permit(Triggers.LoadingFailed, States.LoadingFailed);

            Configure(States.LoadingComplete)
                .PermitReentry(Triggers.ShowInstance)
                .Permit(Triggers.Loading, States.Loading);

            Configure(States.LoadingFailed)
                .Permit(Triggers.Loading, States.Loading);

            OnTransitioned
            (
                (t) => Debug.WriteLine
                (
                    "State Machine transitioned from {0} -> {1} [{2}]",
                    t.Source, t.Destination, t.Trigger
                )
            );
        }

        public string ToGraph()
        {
            this.Initialize();
            return UmlDotGraph.Format(this.GetInfo());
        }
    }
}
