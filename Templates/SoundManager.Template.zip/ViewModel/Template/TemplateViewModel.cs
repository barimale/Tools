﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.CommandWpf;
using GalaSoft.MvvmLight.Threading;
using System;
using System.Threading.Tasks;
using System.Windows.Input;

namespace SoundManager.WPF.ViewModels.Map
{
    public class TemplateViewModel : ViewModelBase
    {
        private object map;
        private bool isWeatherVisible;

        public object Map
        {
            get => map;
            set
            {
                if (value != map)
                {
                    Set(() => Map, ref map, value);
                }
            }
        }

        public bool IsWeatherVisible
        {
            get => isWeatherVisible;
            set
            {
                if (value != isWeatherVisible)
                {
                    Set(() => IsWeatherVisible, ref isWeatherVisible, value);
                }
            }
        }

        public States MachineState => StateMachine.MachineState;
        public ITemplateStateMachine StateMachine { get; set; }
        public ICommand LoadCommand { get; }
        public ICommand RefreshCommand { get; }
        public ICommand ShowWeatherComponentCommand { get; }
        public ICommand SearchCommand { get; }

        public TemplateViewModel(ITemplateStateMachine stateMachine)
        {
            ////if (IsInDesignMode)
            ////{
            ////    // Code runs in Blend --> create design time data.
            ////}
            ////else
            ////{
            ////    // Code runs "for real"
            ////}
            ///
            StateMachine = stateMachine;

            StateMachine.LoadAction = async () => await LoadAsync();

            StateMachine.OnTransitioned
            (
                ( t ) =>
                {
                    this.RaisePropertyChanged(() => this.MachineState );
                    CommandManager.InvalidateRequerySuggested();
                }
            );

            LoadCommand = StateMachine.CreateCommandAsync( Triggers.Loading );
            RefreshCommand = StateMachine.CreateCommandAsync( Triggers.Loading );
            ShowWeatherComponentCommand = new RelayCommand(() =>
            {
                IsWeatherVisible = !IsWeatherVisible;
                this.RaisePropertyChanged(() => IsWeatherVisible);
            });
            SearchCommand = new RelayCommand(async () => await SearchAsync());

            StateMachine.Initialize();

            StateMachine.FireAsync(Triggers.Loading);
        }

        private async Task SearchAsync()
        {
            var i = 0;
        }

        private async Task LoadAsync()
        {
            await DispatcherHelper.RunAsync(async () =>
            {
                try
                {
                    Map = CreateMap();
                    this.RaisePropertyChanged(() => Map);

                    await StateMachine.FireAsync(Triggers.LoadingSucceeded);
                }
                catch (Exception)
                {
                    await StateMachine.FireAsync(Triggers.LoadingFailed);
                }
            });
        }

        private object CreateMap()
        {
            return new object();
        }
    }
}