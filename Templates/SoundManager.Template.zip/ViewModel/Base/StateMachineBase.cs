﻿using System;
using System.Windows.Input;
using SoundManager.WPF.Utilities;
using Stateless;

namespace SoundManager.WPF.ViewModels.Base
{
    public abstract class StateMachineBase<TState, TTrigger> :  StateMachine<TState, TTrigger>
    {
        protected StateMachineBase(TState initialState)
            : base(initialState)
        {
            //intentionally left blank
        }

        protected StateMachineBase(Func<TState> stateAccessor, Action<TState> stateMutator)
            : base(stateAccessor, stateMutator)
        {
            //intentionally left blank
        }

        public ICommand CreateCommand(TTrigger trigger)
        {
            return new RelayCommand
            (
                () => this.Fire(trigger),
                () => this.CanFire(trigger)
            );
        }

        public ICommand CreateCommandAsync(TTrigger trigger)
        {
            return new RelayCommand
            (
                () => this.FireAsync(trigger),
                () => this.CanFire(trigger)
            );
        }
    }
}