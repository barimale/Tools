﻿using System;

namespace SoundManager.WPF.ViewModels.Base
{
    public class TrackedTag
    {
        public Guid TrackedId { get; set; }
        public int TrackedVersion { get; set; }
    }
}
