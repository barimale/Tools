﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Stateless;

namespace SoundManager.WPF.ViewModels.Base
{
    public interface IStateMachineBase<TTriggers, TStates>
    {
        void Initialize();
        void Fire(TTriggers trigger);
        void OnTransitioned(Action<StateMachine<TStates, TTriggers>.Transition> onTransitionAction);
        ICommand CreateCommand(TTriggers trigger);
        ICommand CreateCommandAsync(TTriggers trigger);
        Task FireAsync(TTriggers trigger);
    }
}
