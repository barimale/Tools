using GalaSoft.MvvmLight.Threading;
using SoundManager.CQRS.Configuration;
using SoundManager.WPF.Configuration;
using SoundManager.WPF.ViewModels.Map;

namespace $safeprojectname$.ViewModel
{
    public class ViewModelLocator
    {
        public ViewModelLocator()
        {
            Initialize();
            DispatcherHelper.Initialize();
        }

        public static void Initialize()
        {
            IocKernel.Initialize(
                new Bindings());
        }

        public TemplateViewModel Index
        {
            get
            {
                return IocKernel.Get<TemplateViewModel>();
            }
        }

        public static void Cleanup()
        {
            //Messenger.Default.Send(new CleanUpNotification());
        }

        public static void Dispose()
        {
            IocKernel.Dispose();
        }
    }
}