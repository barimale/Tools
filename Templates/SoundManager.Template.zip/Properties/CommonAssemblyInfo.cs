﻿using System.Reflection;

[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SoundManager.CustomizableBrowser")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
