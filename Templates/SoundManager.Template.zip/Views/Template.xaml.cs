﻿using System.Windows.Controls;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for Template.xaml
    /// </summary>
    public partial class Template : UserControl
    {
        public Template()
        {
            InitializeComponent();
        }
    }
}
