﻿using EntityFramework.DbContextScope.Interfaces;
using SoundManager.CQRS.ReadModel.Dtos;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace SoundManager.CQRS.ReadModel
{
    public class DataStoreContext : DbContext, IDbContext
    {
        public DataStoreContext() : base("DataStore")
        {
            Database.SetInitializer(DroppingStrategy.Get<DataStoreContext>());
        }

        public DbSet<SnapshotDto> SnapshotsHistory { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            modelBuilder.Configurations.Add(new SnapshotConfiguration());
        }
    }

    internal class SnapshotConfiguration : EntityTypeConfiguration<SnapshotDto>
    {
        public SnapshotConfiguration()
        {
            Property(p => p.Guid)
                .IsRequired();

            Property(p => p.ExecutorId)
                .IsRequired();

            Property(p => p.ExecutionTime)
                .IsRequired();

            Property(p => p.ExecutionTime)
                .HasColumnType("datetime2");
        }
    }
}