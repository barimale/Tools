﻿using SoundManager.CQRS.ReadModel.Dtos;
using System;
using System.Threading.Tasks;
using TableDependency.SqlClient.Base.EventArgs;

namespace SoundManager.CQRS.ReadModel.Queries
{
    public interface ISnapshotQuery : IBaseQuery<SnapshotDto>
    {
        event EventHandler<RecordChangedEventArgs<SnapshotDto>> ChangeRaised;
        Task<SnapshotDto> GetLastSnapshotAsync(string userId);
    }
}
