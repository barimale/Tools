﻿using EntityFramework.DbContextScope.Interfaces;
using SoundManager.CQRS.ReadModel.Dtos;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using TableDependency.SqlClient;
using TableDependency.SqlClient.Base.EventArgs;

namespace SoundManager.CQRS.ReadModel.Queries
{
    public class SnapshotQuery : ISnapshotQuery
    {
        private static string TableName = "SnapshotDto";
        private readonly IDbContextScopeFactory _dbContextScopeFactory;
        private readonly SqlTableDependency<SnapshotDto> Table;

        public event EventHandler<RecordChangedEventArgs<SnapshotDto>> ChangeRaised;

        public SnapshotQuery(IDbContextScopeFactory dbContextScopeFactory)
        {
            _dbContextScopeFactory = dbContextScopeFactory;
            var connectionString = ConfigurationManager.ConnectionStrings["DataStore"].ConnectionString;
            Table = new SqlTableDependency<SnapshotDto>(connectionString, TableName);
            Table.OnChanged += OnChangeRaised;
            Table.OnError += Table_OnError;
            Table.Start();
        }

        private void Table_OnError(object sender, ErrorEventArgs e)
        {
            var builder = new StringBuilder();

            builder.Append("Table_OnError: ");
            builder.Append("sender: ");
            builder.Append(sender.ToString());
            builder.AppendLine();

            builder.Append("ErrorEventArgs: ");
            builder.Append(e.Message);

            Helper.Log.Error(builder.ToString());

            Table.Start();
        }

        private void OnChangeRaised(object sender, RecordChangedEventArgs<SnapshotDto> e)
        {
            EventHandler<RecordChangedEventArgs<SnapshotDto>> handler = ChangeRaised;
            handler?.Invoke(this, e);
        }

        public async Task<SnapshotDto> FindByAsync(Expression<Func<SnapshotDto, bool>> predicate)
        {
            using (var dbContextScope = _dbContextScopeFactory.CreateReadOnly())
            {
                var dbContext = dbContextScope.DbContexts.Get<DataStoreContext>();

                return await dbContext
                    .SnapshotsHistory
                    .AsQueryable()
                    .Where(predicate)
                    .FirstOrDefaultAsync();
            }
        }

        public async Task<SnapshotDto> FindByAsync(Guid id)
        {
            using (var dbContextScope = _dbContextScopeFactory.CreateReadOnly())
            {
                var dbContext = dbContextScope.DbContexts.Get<DataStoreContext>();

                return await dbContext
                    .SnapshotsHistory
                    .AsQueryable()
                    .FirstOrDefaultAsync(p => p.Guid == id);
            }
        }

        public async Task<List<SnapshotDto>> GetAllAsync(string userId)
        {
            using (var dbContextScope = _dbContextScopeFactory.CreateReadOnly())
            {
                var dbContext = dbContextScope.DbContexts.Get<DataStoreContext>();

                return await dbContext
                    .SnapshotsHistory
                    .Where(p => p.ExecutorId == userId)
                    .AsQueryable()
                    .ToListAsync();
            }
        }

        public async Task<SnapshotDto> GetLastSnapshotAsync(string userId)
        {
            using (var dbContextScope = _dbContextScopeFactory.CreateReadOnly())
            {
                var dbContext = dbContextScope.DbContexts.Get<DataStoreContext>();

                return await dbContext
                    .SnapshotsHistory
                    .AsQueryable()
                    .Where(p => p.ExecutorId == userId)
                    .OrderByDescending(p => p.Version)
                    .FirstOrDefaultAsync();
            }
        }
    }
}
