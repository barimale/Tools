﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace SoundManager.CQRS.ReadModel.Queries
{
    public interface IBaseQuery<TDbSet>
    {
        Task<List<TDbSet>> GetAllAsync(string userId);
        Task<TDbSet> FindByAsync(Guid id);
        Task<TDbSet> FindByAsync(Expression<Func<TDbSet, bool>> predicate);
    }
}