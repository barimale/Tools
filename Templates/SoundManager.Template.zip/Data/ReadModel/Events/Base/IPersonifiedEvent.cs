﻿namespace SoundManager.CQRS.ReadModel.Events
{
    public interface IPersonifiedEvent
    {
        string ExecutorId { get; set; }
    }
}
