﻿using System;

namespace SoundManager.CQRS.ReadModel.Events.Snapshot
{
    [Serializable]
    public class SnapshotCreatedEvent : BaseEvent, ISnapshot
    {
        public readonly DateTime ExecutionTime;

        public SnapshotCreatedEvent(
            Guid id, 
            DateTime executionTime,
            int version,
            string executorId)
        {
            Id = id;
            ExecutionTime = executionTime;
            Version = version;
            ExecutorId = executorId;
        }
    }
}
