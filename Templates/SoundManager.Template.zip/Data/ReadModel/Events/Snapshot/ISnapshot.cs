﻿namespace SoundManager.CQRS.ReadModel.Events.Snapshot
{
    public interface ISnapshot
    {
        //intentionally left blank
    }
}
