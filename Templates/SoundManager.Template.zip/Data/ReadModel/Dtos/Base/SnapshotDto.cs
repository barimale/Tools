﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SoundManager.CQRS.ReadModel.Dtos
{
    public class SnapshotDto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid Guid { get; set; }
        public int Version { get; set; }
        public string ExecutorId { get; set; }
        public DateTime ExecutionTime { get; set; }
    }
}
