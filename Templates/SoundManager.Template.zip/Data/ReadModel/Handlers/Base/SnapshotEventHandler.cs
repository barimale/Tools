﻿using CQRSlite.Events;
using EntityFramework.DbContextScope.Interfaces;
using Ninject;
using SoundManager.CQRS.ReadModel.Dtos;
using SoundManager.CQRS.ReadModel.Events.Snapshot;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SoundManager.CQRS.ReadModel.Handlers
{
    public class SnapshotEventHandler :
        ICancellableEventHandler<SnapshotCreatedEvent>,
        ICancellableEventHandler<SnapshotUpdatedEvent>
    {
        [Inject]
        public IDbContextScopeFactory _dbContextScopeFactory { get; set; }

        public async Task Handle(SnapshotCreatedEvent createdEvent, CancellationToken token = default)
        {
            using (var dbContextScope = _dbContextScopeFactory.Create())
            {
                var dbContext = dbContextScope.DbContexts.Get<DataStoreContext>();

                dbContext.SnapshotsHistory.Add(new SnapshotDto
                {
                    Guid = createdEvent.Id,
                    Version = createdEvent.Version,
                    ExecutorId = createdEvent.ExecutorId,
                    ExecutionTime = createdEvent.ExecutionTime
                });

                await dbContextScope.SaveChangesAsync(token);
            }
        }

        public async Task Handle(SnapshotUpdatedEvent message, CancellationToken token = default)
        {
            using (var dbContextScope = _dbContextScopeFactory.Create())
            {
                var dbContext = dbContextScope.DbContexts.Get<DataStoreContext>();

                var snap = dbContext.SnapshotsHistory.SingleOrDefault(p => p.Guid == message.Id);
                snap.Version = message.Version;
                snap.ExecutionTime = message.ExecutionTime;

                await dbContextScope.SaveChangesAsync(token);
            }
        }
    }
}