﻿using System.Data.Entity;

namespace SoundManager.CQRS
{
    public static class DroppingStrategy
    {
        private static Strategy selectedStrategy = Strategy.DropCreateDatabaseIfModelChanges;

        public static void Apply(Strategy type)
        {
            selectedStrategy = type;
        }

        public static IDatabaseInitializer<T> Get<T>() where T : DbContext
        {
            switch(selectedStrategy)
            {
                case Strategy.DropCreateDatabaseAlways:
                    return StartFromScratch<T>();
                case Strategy.DropCreateDatabaseIfModelChanges:
                    return ContinouesUsage<T>();
                default:
                    return null;
            }
        }

        private static IDatabaseInitializer<T> ContinouesUsage<T>() where T : DbContext
        {
            return new DropCreateDatabaseIfModelChanges<T>();
        }

        private static IDatabaseInitializer<T> StartFromScratch<T>() where T : DbContext
        {
            return new DropCreateDatabaseAlways<T>();
        }

        public enum Strategy
        {
            DropCreateDatabaseAlways,
            DropCreateDatabaseIfModelChanges
        }
    }
}