﻿using System;
using CQRSlite.Commands;

namespace SoundManager.CQRS.WriteModel.Commands
{
    public abstract class BaseCommand : ICommand
    {
        public string ExecutorId;
        public Guid Id { get; set; }
        public int ExpectedVersion { get; set; }
    }
}
