﻿using System;

namespace SoundManager.CQRS.WriteModel.Commands.Snapshot
{
    public class CreateSnapshotCommand : BaseCommand
    {
        public readonly DateTime ExecutionTime;

        public CreateSnapshotCommand(Guid id, DateTime executionTime, string executorId)
        {
            Id = id;
            ExecutionTime = executionTime;
            ExecutorId = executorId;
        }
    }
}
