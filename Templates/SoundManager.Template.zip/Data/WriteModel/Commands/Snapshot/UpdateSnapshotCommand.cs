﻿using System;

namespace SoundManager.CQRS.WriteModel.Commands.Snapshot
{
    public class UpdateSnapshotCommand : BaseCommand
    {
        public readonly DateTime ExecutionTime;

        public UpdateSnapshotCommand(Guid id, DateTime executionTime, string executorId, int originalVersion)
        {
            Id = id;
            ExecutionTime = executionTime;
            ExecutorId = executorId;
            ExpectedVersion = originalVersion;
        }
    }
}
