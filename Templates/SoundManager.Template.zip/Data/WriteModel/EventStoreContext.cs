﻿using EntityFramework.DbContextScope.Interfaces;
using System.Data.Entity;

namespace SoundManager.CQRS.WriteModel
{
    public class EventStoreContext : DbContext, IDbContext
    {
        public EventStoreContext() : base("EventStore")
        {
            Database.SetInitializer(DroppingStrategy.Get<EventStoreContext>());
        }
    }
}