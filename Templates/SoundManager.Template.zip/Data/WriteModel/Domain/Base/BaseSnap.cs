﻿using System;
using MessagePack;

namespace SoundManager.CQRS.WriteModel.Domain
{
    [MessagePackObject] //TODO: investigate if it is needed at all
    [Serializable]
    public class BaseSnap : CQRSlite.Snapshotting.Snapshot
    {
        public BaseSnap()
        {
            //intentionally left blank
        }
    }
}
