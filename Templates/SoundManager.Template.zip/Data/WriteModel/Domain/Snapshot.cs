﻿using CQRSlite.Snapshotting;
using SoundManager.CQRS.ReadModel.Events.Snapshot;
using System;

namespace SoundManager.CQRS.WriteModel.Domain
{
    public class Snapshot : SnapshotAggregateRoot<BaseSnap>
    {
        private readonly string UserId;

        private Snapshot()
        {
            //intentionally left blank
        }

        public Snapshot(
            Guid id,
            DateTime executionTime,
            int version,
            string userId)
        {
            Id = id;
            UserId = userId;
            Version = version;
            ApplyChange(
                new SnapshotCreatedEvent(
                    id,
                    executionTime,
                    version,
                    userId));
        }

        public void Update()
        {
            ApplyChange(new SnapshotUpdatedEvent(Id, DateTime.UtcNow, Version, UserId));
        }

        protected override BaseSnap CreateSnapshot()
        {
            return new BaseSnap
            {
                Id = this.Id,
                Version = this.Version
            };
        }

        protected override void RestoreFromSnapshot(BaseSnap snapshot)
        {
            Id = snapshot.Id;
            Version = snapshot.Version;
        }
    }
}
