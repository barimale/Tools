﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using CQRSlite.Snapshotting;
using EntityFramework.DbContextScope.Interfaces;
using NEventStore;
using NEventStore.Logging;
using NEventStore.Persistence;
using NEventStore.Persistence.Sql.SqlDialects;
using SoundManager.CQRS.WriteModel.Domain;
using Snapshot = CQRSlite.Snapshotting.Snapshot;

namespace SoundManager.CQRS.WriteModel.SnapshotStore
{
    public class SnapshotStore : ISnapshotStore, IStoreEvents, ISnapshotManager
    {
        private readonly ConcurrentDictionary<Guid, Snapshot> snapshotContentDictionary = new ConcurrentDictionary<Guid, Snapshot>();
        private readonly IStoreEvents EventStore;
        private readonly IDbContext _db;

        public SnapshotStore(IDbContext db)
        {
            _db = db;

            EventStore = Wireup
                .Init()
                .LogToOutputWindow()
                .UsingSqlPersistence("EventStore")
                .WithDialect(new MsSqlDialect())
                .InitializeStorageEngine()
                .UsingBinarySerialization()
                .LogToConsoleWindow(LogLevel.Verbose)
                .Build();
        }

        public IPersistStreams Advanced => EventStore.Advanced;

        public bool Save(string streamId, int streamVersion)
        {
            try
            {
                var innerPayload = snapshotContentDictionary
                    .Values
                    .Select(p => new InnerPayload(p.Id, p.Version))
                    .ToList<object>();

                var snap = new NEventStore.Snapshot(
                    streamId,
                    streamVersion,
                    innerPayload);

                var result = EventStore.Advanced.AddSnapshot(snap);

                return result;
            }
            catch (Exception e)
            {
                Helper.Log.Error(e.Message);
            }

            return false;
        }

        public void Load(string streamId)
        {
            try
            {
                var snap = EventStore
                    .Advanced
                    .GetSnapshot(streamId, int.MaxValue);

                if (snap == null || snap.Payload==null)
                {
                    return;
                }

                var items = snap.Payload as List<object>;
                switch (items)
                {
                    case null:
                        return;
                    default:
                        items.AsParallel().ForAll(p =>
                        {
                            var item = p as InnerPayload;
                            var result = new BaseSnap
                            {
                                Id = item.Id,
                                Version = item.Version
                            };

                            snapshotContentDictionary.TryAdd(result.Id, result);
                        });

                        return;
                }
            }
            catch (Exception e)
            {
                Helper.Log.Error(e.Message);
            }
        }

        public IEventStream CreateStream(string bucketId, string streamId)
        {
            return EventStore.CreateStream(bucketId, streamId);
        }

        public void Dispose()
        {
            EventStore?.Dispose();
        }

        public async Task<Snapshot> Get(Guid id, CancellationToken cancellationToken = default)
        {
            snapshotContentDictionary.TryGetValue(id, out Snapshot result);

            return result;
        }

        public async Task Save(Snapshot snapshot, CancellationToken cancellationToken = default)
        {
            try
            {
                snapshotContentDictionary.AddOrUpdate(snapshot.Id, snapshot, (key, oldValue) => snapshot);
            }
            catch (Exception e)
            {
                Helper.Log.Error(e.Message);
            }
        }

        public IEventStream OpenStream(string bucketId, string streamId, int minRevision, int maxRevision)
        {
            return EventStore.OpenStream(bucketId, streamId, minRevision, maxRevision);
        }

        public IEventStream OpenStream(ISnapshot snapshot, int maxRevision)
        {
            return EventStore.OpenStream(snapshot, maxRevision);
        }
    }
}
