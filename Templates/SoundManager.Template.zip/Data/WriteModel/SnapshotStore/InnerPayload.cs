﻿using System;

namespace SoundManager.CQRS.WriteModel.SnapshotStore
{
    [Serializable]
    internal class InnerPayload
    {
        public InnerPayload()
        {
            //intentionally left blank  
        }

        public InnerPayload(Guid id, int version)
            : this()
        {
            Id = id;
            Version = version;
        }

        public Guid Id { get; set; }

        public int Version { get; set; }
    }
}
