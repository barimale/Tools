﻿using CQRSlite.Commands;
using SoundManager.CQRS.WriteModel.Commands.Snapshot;
using System;
using System.Threading;
using System.Threading.Tasks;
using Snapshot = SoundManager.CQRS.WriteModel.Domain.Snapshot;

namespace SoundManager.CQRS.WriteModel.Handlers
{
    public partial class CommandHandlers :
        ICancellableCommandHandler<CreateSnapshotCommand>,
        ICancellableCommandHandler<UpdateSnapshotCommand>
    {
        public async Task Handle(CreateSnapshotCommand command, CancellationToken token = default)
        {
            try
            {
                var item = new Snapshot(
                    command.Id,
                    command.ExecutionTime,
                    command.ExpectedVersion,
                    command.ExecutorId);

                await Session.Add(item, token);
                await Session.Commit(token);
            }
            catch (Exception e)
            {
                Helper.Log.Error(e.Message);
            }
        }

        public async Task Handle(UpdateSnapshotCommand message, CancellationToken token = default)
        {
            try
            {
                var item = await Session.Get<Snapshot>(message.Id, message.ExpectedVersion, token);

                item.Update();
                await Session.Commit(token);
            }
            catch (Exception e)
            {
                Helper.Log.Error(e.Message);
            }
        }
    }
}
