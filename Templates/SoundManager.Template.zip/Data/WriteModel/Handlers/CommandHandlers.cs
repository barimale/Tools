﻿using CQRSlite.Domain;

namespace SoundManager.CQRS.WriteModel.Handlers
{
    public partial class CommandHandlers
    {
        private readonly ISession Session;

        public CommandHandlers(ISession session)
        {
            Session = session;
        }

        //As it is partial class, please implement new handlers in separated classes.
    }
}
