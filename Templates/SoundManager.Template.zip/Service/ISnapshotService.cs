﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace SoundManager.Services.Interfaces
{
    public interface ISnapshotService
    {
        Task<bool> LoadAsync(string userId, CancellationToken token = default);
        Task<bool> SaveAsync(string userId, CancellationToken token = default);

        event EventHandler Finished;
    }
}