﻿using CQRSlite.Commands;
using SoundManager.CQRS;
using SoundManager.CQRS.ReadModel.Dtos;
using SoundManager.CQRS.ReadModel.Queries;
using SoundManager.CQRS.WriteModel.Commands.Snapshot;
using SoundManager.CQRS.WriteModel.SnapshotStore;
using SoundManager.Services.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;
using TableDependency.SqlClient.Base.EventArgs;

namespace SoundManager.Services.IdentityAndAccessManagement
{
    public class SnapshotService : ISnapshotService
    {
        private readonly ICommandSender CommandSender;
        private readonly ISnapshotQuery Readmodel;
        private readonly ISnapshotManager Manager;

        private SnapshotService()
        {
            //intentionally left blank
        }

        public SnapshotService(
            ICommandSender commandSender,
            ISnapshotQuery readmodel,
            ISnapshotManager manager)
            :this()
        {
            CommandSender = commandSender;
            Readmodel = readmodel;
            Readmodel.ChangeRaised += OnChangeRaised;
            Manager = manager;
        }

        public event EventHandler Finished;

        private void OnChangeRaised(object sender, RecordChangedEventArgs<SnapshotDto> e)
        {
            switch (e.Entity)
            {
                case null:
                    break;
                default:
                    Manager.Save(e.Entity.Guid.ToString(), e.Entity.Version);
                    EventHandler handler = Finished;
                    handler?.Invoke(this, EventArgs.Empty);
                    break;
            }
        }

        public async Task<bool> SaveAsync(string userId, CancellationToken token)
        {
            try
            {
                return await Task.Run(async () =>
                { 
                    var latestSnapshot = await Readmodel.GetLastSnapshotAsync(userId);

                    if (latestSnapshot == null)
                    {
                        await CommandSender.Send(
                            new CreateSnapshotCommand(
                                Guid.NewGuid(),
                                DateTime.UtcNow,
                                userId));
                    }
                    else
                    {
                        await CommandSender.Send(
                            new UpdateSnapshotCommand(
                                latestSnapshot.Guid,
                                DateTime.UtcNow,
                                userId,
                                latestSnapshot.Version));
                    }

                    return true;
                },token);
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Helper.Log.Error(ex.Message);
                return false;
            }
        }

        public async Task<bool> LoadAsync(string executorId, CancellationToken token)
        {
            try
            {
                return await Task.Run(async () =>
                {
                    var latestSnapshot = await Readmodel.GetLastSnapshotAsync(executorId);

                    if (latestSnapshot != null)
                    {
                        Manager.Load(latestSnapshot.Guid.ToString());
                    }

                    return true;
                }, token);
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Helper.Log.Error(ex.Message);
                return false;
            }
        }
    }
}