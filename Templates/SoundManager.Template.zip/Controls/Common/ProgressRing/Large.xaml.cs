﻿using GalaSoft.MvvmLight.Threading;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace SoundManager.WPF.Controls.Common.ProgressRing
{
    /// <summary>
    /// Interaction logic for Large.xaml
    /// </summary>
    public partial class Large : UserControl
    {
        private static readonly List<string> DefaultLoadingSteps = new List<string>
        {
            "Loading",
            " Loading.",
            "  Loading..",
            "   Loading...",
            "  Loading..",
            " Loading."
        };

        private static DispatcherTimer timer;
        private static int indexHelper = 0;

        public static readonly DependencyProperty IsActiveProperty = DependencyProperty.Register(
            "IsActive",
            typeof(bool),
            typeof(Large),
            new FrameworkPropertyMetadata(
                false,
                new PropertyChangedCallback(OnIsActiveChanged)));

        public static readonly DependencyProperty IntervalTimeInMillisecondsProperty = DependencyProperty.Register(
            "IntervalTimeInMilliseconds",
            typeof(int),
            typeof(Large),
            new PropertyMetadata(700));

        public static readonly DependencyProperty AnimationInputProperty = DependencyProperty.Register(
            "AnimationInput",
            typeof(List<string>),
            typeof(Large),
            new PropertyMetadata(DefaultLoadingSteps));

        public static readonly DependencyProperty FrameProperty = DependencyProperty.Register(
            "Frame",
            typeof(string),
            typeof(Large),
            new PropertyMetadata(string.Empty));

        public Large()
        {
            InitializeComponent();
            timer = new DispatcherTimer(DispatcherPriority.Render)
            {
                Interval = TimeSpan.FromMilliseconds(IntervalTimeInMilliseconds)
            };

            timer.Tick += OnTick;
            Frame = DefaultLoadingSteps[0];
        }

        private static void OnIsActiveChanged(
            DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
            {
                timer.Start();
            }
            else
            {
                timer.Stop();
            }
        }

        private void OnTick(object sender, EventArgs e)
        {
            DispatcherHelper.RunAsync(() =>
            {
                Frame = AnimationInput[indexHelper];
                indexHelper += 1;
                if (indexHelper >= AnimationInput.Count) indexHelper = 0;
            });
        }

        public int IntervalTimeInMilliseconds
        {
            get => (int)GetValue(IntervalTimeInMillisecondsProperty);
            set => SetValue(IntervalTimeInMillisecondsProperty, value);
        }

        public string Frame
        {
            get => (string)GetValue(FrameProperty);
            private set => SetValue(FrameProperty, value);
        }

        public bool IsActive
        {
            get => (bool)GetValue(IsActiveProperty);
            set => SetValue(IsActiveProperty, value);
        }

        public List<string> AnimationInput
        {
            get => (List<string>)GetValue(AnimationInputProperty);
            set => SetValue(AnimationInputProperty, value);
        }
    }
}
