﻿using System.Windows;
using System.Windows.Controls;

namespace SoundManager.WPF.Controls.Common.Labels
{
    /// <summary>
    /// Interaction logic for InvertedMediumHeader.xaml
    /// </summary>
    public partial class InvertedMediumHeader : UserControl
    {
        public static readonly DependencyProperty HeaderProperty = DependencyProperty.Register(
            "Header",
            typeof(string),
            typeof(InvertedMediumHeader),
            new PropertyMetadata(string.Empty));

        public InvertedMediumHeader()
        {
            InitializeComponent();
        }

        public string Header
        {
            get => (string)GetValue(HeaderProperty);
            set => SetValue(HeaderProperty, value);
        }
    }
}
