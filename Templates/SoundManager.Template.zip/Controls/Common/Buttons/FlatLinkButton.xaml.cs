﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SoundManager.WPF.Controls.Common.Buttons
{
    /// <summary>
    /// Interaction logic for FlatLinkButton.xaml
    /// </summary>
    public partial class FlatLinkButton : UserControl
    {
        public static readonly DependencyProperty MyHeightProperty = DependencyProperty.Register(
            "MyHeight",
            typeof(int),
            typeof(FlatLinkButton),
            new PropertyMetadata(40));

        public static readonly DependencyProperty MyWidthProperty = DependencyProperty.Register(
            "MyWidth",
            typeof(int),
            typeof(FlatLinkButton),
            new PropertyMetadata(100));

        public static readonly DependencyProperty MyCommandProperty = DependencyProperty.Register(
            "MyCommand",
            typeof(ICommand),
            typeof(FlatLinkButton),
            new PropertyMetadata(null));

        public static readonly DependencyProperty MyContentProperty = DependencyProperty.Register(
            "MyContent",
            typeof(string),
            typeof(FlatLinkButton),
            new PropertyMetadata(string.Empty));

        public static readonly DependencyProperty MyMachineStateVisibilityProperty = DependencyProperty.Register(
            "MyMachineStateVisibility",
            typeof(Visibility),
            typeof(FlatLinkButton),
            new PropertyMetadata(Visibility.Visible));

        public FlatLinkButton()
        {
            InitializeComponent();
        }

        public int MyHeight
        {
            get => (int) GetValue(MyHeightProperty);
            set => SetValue(MyHeightProperty, value);
        }

        public int MyWidth
        {
            get => (int)GetValue(MyWidthProperty);
            set => SetValue(MyWidthProperty, value);
        }

        public string MyContent
        {
            get => (string)GetValue(MyContentProperty);
            set => SetValue(MyContentProperty, value);
        }

        public ICommand MyCommand
        {
            get => (ICommand)GetValue(MyCommandProperty);
            set => SetValue(MyCommandProperty, value);
        }

        public Visibility MyMachineStateVisibility
        {
            get => (Visibility)GetValue(MyMachineStateVisibilityProperty);
            set => SetValue(MyMachineStateVisibilityProperty, value);
        }
    }
}
