﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace SoundManager.WPF.Controls.Common.Buttons
{
    /// <summary>
    /// Interaction logic for RoundTextButton.xaml
    /// </summary>
    public partial class RoundTextButton : UserControl
    {
        public static readonly DependencyProperty MyHeightProperty = DependencyProperty.Register(
            "MyHeight",
            typeof(int),
            typeof(RoundTextButton),
            new PropertyMetadata(55));

        public static readonly DependencyProperty MyWidthProperty = DependencyProperty.Register(
            "MyWidth",
            typeof(int),
            typeof(RoundTextButton),
            new PropertyMetadata(55));

        public static readonly DependencyProperty MyIconHeightProperty = DependencyProperty.Register(
            "MyIconHeight",
            typeof(int),
            typeof(RoundTextButton),
            new PropertyMetadata(35));

        public static readonly DependencyProperty MyIconWidthProperty = DependencyProperty.Register(
            "MyIconWidth",
            typeof(int),
            typeof(RoundTextButton),
            new PropertyMetadata(35));

        public static readonly DependencyProperty MyIconResourceNameProperty = DependencyProperty.Register(
            "MyIconResourceName",
            typeof(Visual),
            typeof(RoundTextButton),
            new PropertyMetadata(default(Visual)));

        public static readonly DependencyProperty MyCommandProperty = DependencyProperty.Register(
            "MyCommand",
            typeof(ICommand),
            typeof(RoundTextButton),
            new PropertyMetadata(null));

        public static readonly DependencyProperty MyBackgroundConditionProperty = DependencyProperty.Register(
            "MyBackgroundCondition",
            typeof(bool),
            typeof(RoundTextButton),
            new PropertyMetadata(false));

        public static readonly DependencyProperty MyContentProperty = DependencyProperty.Register(
            "MyContent",
            typeof(string),
            typeof(RoundTextButton),
            new PropertyMetadata(string.Empty));

        public RoundTextButton()
        {
            InitializeComponent();
        }

        public int MyHeight
        {
            get => (int) GetValue(MyHeightProperty);
            set => SetValue(MyHeightProperty, value);
        }

        public int MyWidth
        {
            get => (int)GetValue(MyWidthProperty);
            set => SetValue(MyWidthProperty, value);
        }

        public int MyIconHeight
        {
            get => (int)GetValue(MyIconHeightProperty);
            set => SetValue(MyIconHeightProperty, value);
        }

        public int MyIconWidth
        {
            get => (int)GetValue(MyIconWidthProperty);
            set => SetValue(MyIconWidthProperty, value);
        }

        public Visual MyIconResourceName
        {
            get => (Visual)GetValue(MyIconResourceNameProperty);
            set => SetValue(MyIconResourceNameProperty, value);
        }

        public bool MyBackgroundCondition
        {
            get => (bool)GetValue(MyBackgroundConditionProperty);
            set => SetValue(MyBackgroundConditionProperty, value);
        }

        public ICommand MyCommand
        {
            get => (ICommand)GetValue(MyCommandProperty);
            set => SetValue(MyCommandProperty, value);
        }

        public string MyContent
        {
            get => (string)GetValue(MyContentProperty);
            set => SetValue(MyContentProperty, value);
        }
    }
}
