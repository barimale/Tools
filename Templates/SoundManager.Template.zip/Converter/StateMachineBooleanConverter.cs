﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace SoundManager.WPF.Converter
{
    public class StateMachineBooleanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType,
            object parameter, CultureInfo culture)
        {
            var state = value != null ?
                value.ToString() : string.Empty;
            var targetState = parameter?.ToString();
            return state == targetState;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return Binding.DoNothing;
        }
    }
}
