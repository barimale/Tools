﻿using CommonServiceLocator.NinjectAdapter.Unofficial;
using CQRSlite.Caching;
using CQRSlite.Commands;
using CQRSlite.Domain;
using CQRSlite.Events;
using CQRSlite.Messages;
using CQRSlite.Routing;
using CQRSlite.Snapshotting;
using EntityFramework.DbContextScope;
using EntityFramework.DbContextScope.Interfaces;
using Microsoft.Practices.ServiceLocation;
using NEventStore;
using Ninject.Extensions.Conventions;
using Ninject.Modules;
using SoundManager.CQRS.ReadModel.Queries;
using SoundManager.CQRS.WriteModel;
using SoundManager.CQRS.WriteModel.EventStore;
using SoundManager.CQRS.WriteModel.Handlers;
using SoundManager.CQRS.WriteModel.SnapshotStore;
using SoundManager.Services.IdentityAndAccessManagement;
using SoundManager.Services.Interfaces;
using SoundManager.WPF.ViewModels.Map;
using System;
using System.Linq;
using System.Reflection;

namespace SoundManager.CQRS.Configuration
{
    public class Bindings : NinjectModule
    {
        public override void Load()
        {
            Bind<TemplateViewModel>()
                .ToSelf()
                .WithConstructorArgument(typeof(ITemplateStateMachine));

            Bind<ITemplateStateMachine>()
                .To<TemplateStateMachine>()
                .InSingletonScope();

            Bind<ISnapshotService>()
                .To<SnapshotService>()
                .InSingletonScope();

            Bind<IDbContextScopeFactory>()
                .To<DbContextScopeFactory>()
                .InSingletonScope();

            Bind<ISnapshotQuery>()
                .To<SnapshotQuery>()
                .InTransientScope();

            Bind<IDbContext>()
                .To<EventStoreContext>()
                .WhenInjectedExactlyInto<SnapshotStore>()
                .InSingletonScope();

            Bind<Router>()
                .ToSelf()
                .InSingletonScope();

            Bind<ICommandSender, IEventPublisher, IHandlerRegistrar>()
                .To<Router>()
                .InSingletonScope();

            Bind<IStoreEvents, ISnapshotStore, ISnapshotManager>()
                .To<SnapshotStore>()
                .InSingletonScope();

            Bind<IEventStore>()
                .To<EventStore>()
                .InSingletonScope();

            Bind<ICache>()
                .To<MemoryCache>()
                .InSingletonScope();

            Bind<IRepository>()
                .To<Repository>()
                .WhenInjectedExactlyInto(typeof(SnapshotRepository))
                .InSingletonScope();

            Bind<IRepository>()
                .To<SnapshotRepository>()
                .WithConstructorArgument(typeof(ISnapshotStore))
                .WithConstructorArgument(typeof(ISnapshotStrategy))
                .WithConstructorArgument(typeof(IRepository))
                .WithConstructorArgument(typeof(IEventStore));

            Bind<ISnapshotStrategy>()
                .To<CustomSnapshotStrategy>()
                .InSingletonScope();

            Bind<ISession>()
                .To<Session>();

            Kernel.Bind(x =>
            {
                x.From(
                    typeof(CommandHandlers).GetTypeInfo().Assembly)
                    .SelectAllClasses()
                    .Where(p =>
                    {
                        var allInterfaces = p.GetInterfaces();
                        return
                            allInterfaces.Any(y => y.GetTypeInfo().IsGenericType && y.GetTypeInfo().GetGenericTypeDefinition() == typeof(IHandler<>)) ||
                            allInterfaces.Any(y => y.GetTypeInfo().IsGenericType && y.GetTypeInfo().GetGenericTypeDefinition() == typeof(ICancellableHandler<>));
                    })
                .BindToSelf();
            }); 

            ServiceLocator.SetLocatorProvider(() => new NinjectServiceLocator(Kernel));

            var registerer = new RouteRegistrar(new Provider(new NinjectServiceLocator(Kernel)));
            registerer.RegisterInAssemblyOf(
                typeof(CommandHandlers));
        }

        public class Provider : IServiceProvider
        {
            private readonly IServiceLocator _serviceProvider;

            public Provider(IServiceLocator serviceProvider)
            {
                _serviceProvider = serviceProvider;
            }

            public object GetService(Type serviceType)
            {
                return _serviceProvider.GetService(serviceType);
            }
        }
    }
}
