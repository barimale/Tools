﻿using System.Linq;
using Ninject;
using Ninject.Activation.Caching;
using Ninject.Modules;
using SoundManager.CQRS.Configuration;

namespace SoundManager.WPF.Configuration
{
    public static class IocKernel
    {
        public static StandardKernel Kernel { get; private set; }

        public static T Get<T>()
        {
            return Kernel.Get<T>();
        }

        public static void Initialize(params INinjectModule[] modules)
        {
            Kernel = new StandardKernel(new NinjectSettings() { LoadExtensions = true }, modules);
        }

        public static void Unload()
        {
            foreach (var module in Kernel.GetModules().Where(m => m is Bindings))
            {
                Kernel.Unload(module.Name);
            }

            Kernel.Components.Get<ICache>().Clear();
        }

        public static void Dispose()
        {
            Unload();
            //Kernel.Dispose(true);
        }
    }
}
