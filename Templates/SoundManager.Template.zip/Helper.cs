﻿using NLog;

namespace SoundManager.CQRS
{
    public static class Helper
    {
        public static Logger Log => LogManager.GetCurrentClassLogger();
    }
}
